package com.java.customersDataMngmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomersDataManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomersDataManagementApplication.class, args);
	}

}
