package com.java.customersDataMngmt.config;

import org.springframework.batch.item.ItemProcessor;

import com.java.customersDataMngmt.entity.Customer;

public class CustomerProcessor implements ItemProcessor<Customer,Customer> {

    @Override
    public Customer process(Customer customer) throws Exception {
            return customer;
    }
}
